graphics-coursework-raytracing
==============================

 A graphics coursework to make a simple ray tracer. Implemented in Haskell. 